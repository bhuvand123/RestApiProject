package com.examly.library.repository;

import com.examly.library.model.Faq;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface FaqRepository extends JpaRepository<Faq, Integer> {
    @Modifying
    @Query(value="insert into Faq(id,name,text,details) values(?,?,?,?)",nativeQuery = true)
    void postFaq(int id,String name,String text,String details);

    @Query("Select a from Faq a")
    List<Faq> getUsers();

    @Query("SELECT a FROM Faq a WHERE a.id = :id")
    List<Faq> getById(@Param("id") int id);
}  