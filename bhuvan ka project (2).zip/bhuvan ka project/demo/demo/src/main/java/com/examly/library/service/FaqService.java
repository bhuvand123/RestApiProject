package com.examly.library.service;

import com.examly.library.model.Faq;
import com.examly.library.repository.FaqRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FaqService {

    @Autowired
    FaqRepository FaqRepository;

    public Faq createFaq(Faq Faq) {
        return FaqRepository.save(Faq);
    }

    public List<Faq> getAllFaqs() {
        return FaqRepository.findAll();
    }

    public Optional<Faq> getFaqById(int id) {
        return FaqRepository.findById(id);
    }

    public Faq updateFaq(int id, Faq newFaq) {
        return FaqRepository.findById(id).map(existingFaq -> {
            if(newFaq.getName() != null)existingFaq.setName(newFaq.getName()); 
            if(newFaq.getText() != null)existingFaq.setText(newFaq.getText());
            if(newFaq.getDetails() != null)existingFaq.setDetails(newFaq.getDetails());
            return FaqRepository.save(existingFaq);
        }).orElseThrow(() -> new IllegalArgumentException("Faq not found with id " + id)); 
    }
    

    public void deleteFaq(int id) {
            if (FaqRepository.existsById(id))
             {
                FaqRepository.deleteById( id);
            } 
            else 
            {
                throw new RuntimeException("Faq not found with id " + id);
            }
    }

    public List<Faq> sort(String field)
    {
        Sort sort=Sort.by(Sort.Direction.ASC,field);
        return FaqRepository.findAll(sort);
    }

    public List<Faq> page(int pageSize,int pageNumber)
    {
        PageRequest page= PageRequest.of(pageNumber, pageSize);
        return FaqRepository.findAll(page).getContent(); 
    }
}
