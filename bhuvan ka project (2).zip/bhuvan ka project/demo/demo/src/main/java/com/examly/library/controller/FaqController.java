package com.examly.library.controller;

import com.examly.library.model.Faq;
import com.examly.library.service.FaqService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class FaqController {

    @Autowired
    FaqService FaqService;

    @PostMapping("/post")
    public ResponseEntity<Faq> createFaq(@RequestBody Faq Faq) {
       return new ResponseEntity<>(FaqService.createFaq(Faq),HttpStatus.ACCEPTED);
    }

    @GetMapping("/getdata")
    public ResponseEntity<List<Faq>> getAllFaqs() {
        return new ResponseEntity<>(FaqService.getAllFaqs(), HttpStatus.OK);
    }

    @GetMapping("/getdata/{id}")
    public ResponseEntity<Faq> getFaqById(@PathVariable int id) {
        return FaqService.getFaqById(id)
                  .map(Faq -> new ResponseEntity<>(Faq, HttpStatus.OK))
                  .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/update/{id}") 
    public ResponseEntity<Faq> updateFaq(@PathVariable int id, @RequestBody Faq newFaq) {
    try {
        Faq updatedFaq = FaqService.updateFaq(id, newFaq);
        return new ResponseEntity<>(updatedFaq, HttpStatus.OK);
    } catch (IllegalArgumentException e) { 
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
    @DeleteMapping("/deletedata/{id}")
    public ResponseEntity<Void> deleteFaq(@PathVariable int id) {
        try {
            FaqService.deleteFaq(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/getdata/sortBy/{field}")
    public List<Faq> g(@PathVariable String field)
    {
        return FaqService.sort(field);
    }

    @GetMapping("/getdata/paginated/{offset}/{pagesize}")
    public List<Faq> get(@PathVariable int offset,@PathVariable int pagesize)
    {
        return FaqService.page(pagesize, offset);
    }
}
