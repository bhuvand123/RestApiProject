package com.examly.library.repository;

import com.examly.library.model.Inquiry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
public interface InquiryRepository extends JpaRepository<Inquiry, Long> {

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO inquiry (title, faq_id, details) VALUES (:title, :faqId, :details)", nativeQuery = true)
    void saveInquiry(@Param("title") String title, @Param("faqId") Long faqId, @Param("details") String details);

    @Query("SELECT i FROM Inquiry i")
    List<Inquiry> getAllInquiries();

    @Query("SELECT i FROM Inquiry i WHERE i.id = :id")
    Inquiry getById(@Param("id") Long id);
}
