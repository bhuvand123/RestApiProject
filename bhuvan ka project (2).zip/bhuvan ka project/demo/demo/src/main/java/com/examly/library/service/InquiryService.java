package com.examly.library.service;

import com.examly.library.model.Inquiry;
import com.examly.library.repository.InquiryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InquiryService {

    @Autowired
    private InquiryRepository inquiryRepository;

    // Create Inquiry
    public Inquiry createInquiry(Inquiry inquiry) {
        return inquiryRepository.save(inquiry);
    }

    // Get All Inquiries
    public List<Inquiry> getAllInquiries() {
        return inquiryRepository.findAll();
    }

    // Get Inquiry by ID
    public Optional<Inquiry> getInquiryById(Long id) {
        return inquiryRepository.findById(id);
    }

    // Update Inquiry
    public Inquiry updateInquiry(Long id, Inquiry newInquiry) {
        return inquiryRepository.findById(id).map(existingInquiry -> {
            if (newInquiry.getTitle() != null) existingInquiry.setTitle(newInquiry.getTitle());
            if (newInquiry.getDetails() != null) existingInquiry.setDetails(newInquiry.getDetails());
            return inquiryRepository.save(existingInquiry);
        }).orElseThrow(() -> new IllegalArgumentException("Inquiry not found with ID " + id));
    }

    // Delete Inquiry
    public void deleteInquiry(Long id) {
        if (inquiryRepository.existsById(id)) {
            inquiryRepository.deleteById(id);
        } else {
            throw new IllegalArgumentException("Inquiry not found with ID " + id);
        }
    }

    // Sort Inquiries
    public List<Inquiry> sort(String field) {
        return inquiryRepository.findAll(Sort.by(Sort.Direction.ASC, field));
    }

    // Paginate Inquiries
    public List<Inquiry> page(int pageSize, int pageNumber) {
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        return inquiryRepository.findAll(pageable).getContent();
    }
}
