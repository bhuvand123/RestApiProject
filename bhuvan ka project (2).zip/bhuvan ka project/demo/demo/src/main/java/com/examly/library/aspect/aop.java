package com.examly.library.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class aop 
{
    @Before("execution(* com.examly.library.controller.AuthorController.getAllAuthors(..))")
    public void display1() 
    {
        System.out.println("Before method execution");
    }
    @After("execution(* com.examly.library.controller.AuthorController.getAllAuthors(..))")
    public void display2() 
    {
        System.out.println("After method execution");
    }    
}
