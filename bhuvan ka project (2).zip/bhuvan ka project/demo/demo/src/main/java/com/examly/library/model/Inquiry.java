package com.examly.library.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
public class Inquiry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Changed type to Long

    private String title;
    private String details;

    @ManyToOne
    @JoinColumn(name = "faq_id", referencedColumnName = "id") // Foreign key to Faq
    @JsonBackReference
    private Faq faq;

    // Constructors
    public Inquiry() {
    }

    public Inquiry(Long id, String title, String details, Faq faq) {
        this.id = id;
        this.title = title;
        this.details = details;
        this.faq = faq;
    }

    // Getters & Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Faq getFaq() {
        return faq;
    }

    public void setFaq(Faq faq) {
        this.faq = faq;
    }
}
