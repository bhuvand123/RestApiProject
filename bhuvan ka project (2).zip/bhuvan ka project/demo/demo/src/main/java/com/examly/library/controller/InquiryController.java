package com.examly.library.controller;

import com.examly.library.model.Inquiry;
import com.examly.library.service.InquiryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/inquiries")
public class InquiryController {

    @Autowired
    private InquiryService inquiryService;

    // Create Inquiry
    @PostMapping
    public ResponseEntity<Inquiry> createInquiry(@RequestBody Inquiry inquiry) {
        Inquiry savedInquiry = inquiryService.createInquiry(inquiry);
        return new ResponseEntity<>(savedInquiry, HttpStatus.CREATED);
    }

    // Get All Inquiries
    @GetMapping
    public ResponseEntity<List<Inquiry>> getAllInquiries() {
        return new ResponseEntity<>(inquiryService.getAllInquiries(), HttpStatus.OK);
    }

    // Get Inquiry by ID
    @GetMapping("/{id}")
    public ResponseEntity<Inquiry> getInquiryById(@PathVariable Long id) {
        Optional<Inquiry> inquiry = inquiryService.getInquiryById(id);
        return inquiry.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                      .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Update Inquiry
    @PutMapping("/{id}")
    public ResponseEntity<Inquiry> updateInquiry(@PathVariable Long id, @RequestBody Inquiry newInquiry) {
        try {
            Inquiry updatedInquiry = inquiryService.updateInquiry(id, newInquiry);
            return new ResponseEntity<>(updatedInquiry, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete Inquiry
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInquiry(@PathVariable Long id) {
        try {
            inquiryService.deleteInquiry(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Sort Inquiries
    @GetMapping("/sortBy/{field}")
    public ResponseEntity<List<Inquiry>> getSortedInquiries(@PathVariable String field) {
        return new ResponseEntity<>(inquiryService.sort(field), HttpStatus.OK);
    }

    // Paginate Inquiries
    @GetMapping("/paginated/{offset}/{pageSize}")
    public ResponseEntity<List<Inquiry>> getPaginatedInquiries(@PathVariable int offset, @PathVariable int pageSize) {
        return new ResponseEntity<>(inquiryService.page(pageSize, offset), HttpStatus.OK);
    }
}
